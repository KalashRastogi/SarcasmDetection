import pandas as pd
from dl_text import dl
import numpy as np
from keras.layers import Input, Dense, Dropout, merge, Conv1D, Lambda, Flatten, MaxPooling1D,MaxPooling2D
from keras.models import Model
import keras

def model_cnn2(dimx, dimy, embedding_matrix):
    inpx = Input(shape=(dimx,),dtype='int32',name='inpx')   
    embedx = dl.word2vec_embedding_layer(embedding_matrix)(inpx)
    inpy = Input(shape=(dimy,),dtype='int32',name='inpy')   
    embedy = dl.word2vec_embedding_layer(embedding_matrix)(inpy)
    
    sent_l = Conv1D(nb_filter=3,filter_length=2,activation='relu')(embedx)
    sent_r = Conv1D(nb_filter=3,filter_length=2,activation='relu')(embedy)
    pool_l = MaxPooling1D()(sent_l)
    pool_r = MaxPooling1D()(sent_r)

    combine  = keras.layers.Add()([pool_l,pool_r])
    flat_embed = Flatten()(combine)
    nnet_h = Dense(units=10,activation='sigmoid')(flat_embed)
    nnet_out = Dense(units=2,activation='sigmoid')(nnet_h)
    model = Model([inpx,inpy],nnet_out)
    model.compile(loss='mse',optimizer='adam')
    
    return model

df = pd.read_csv('sarcasm_v2.csv')
df = df.drop(columns=['Corpus','ID'])
df = df.replace({'sarc':'1','notsarc':'0'})
label = df['Label'].tolist()
qt = df['Quote Text'].tolist()
rt = df['Response Text'].tolist()

labels = []
q = []
r = []
for sent1,sent2,l in zip(rt,qt,label):
    r.append(dl.clean(sent1))
    q.append(dl.clean(sent2))
    labels.append(dl.clean(l))

labels = [int(i) for i in labels]
labels = keras.utils.to_categorical(labels)

f = open('glove.6B.50d.txt', encoding="utf8")
model = {}
for line in f:
    splitline = line.split()
    word = splitline[0]
    embedding = np.array([float(val) for val in splitline[1:]])
    model[word] = embedding
    
wordvec_model = model

data_inp_l, data_inp_r, embedding_matrix = dl.process_data(sent_l = q, sent_r = r, wordVec_model = wordvec_model, dimx = 100, dimy = 100)
model = model_cnn2(dimx = 100, dimy = 100, embedding_matrix = embedding_matrix)
model.fit([data_inp_l,data_inp_r],labels)

