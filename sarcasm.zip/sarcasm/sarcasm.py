import pandas as pd
from dl_text import dl
import numpy as np
from keras.layers import Input, Dense, Dropout, merge, Conv1D, Lambda, Flatten, MaxPooling1D,MaxPooling2D
from keras.models import Model

def model_cnn(dimx, embedding_matrix):
    inpx = Input(shape=(dimx,),dtype='int32',name='inpx')   
    embed = dl.word2vec_embedding_layer(embedding_matrix)(inpx)
    sent = Conv1D(nb_filter=3,filter_length=2,activation='relu')(embed)
    pool = MaxPooling1D(sent)
    flat_embed = Flatten()(pool)
    nnet_h = Dense(units=10,activation='sigmoid')(flat_embed)
    nnet_out = Dense(units=2,activation='sigmoid')(nnet_h)
    model = Model([inpx],nnet_out)
    model.compile(loss='mse',optimizer='adam')
    return model

df = pd.read_csv('sarcasm_v2.csv')
df = df.drop(columns=['Corpus','ID'])
df = df.replace({'sarc':'1','notsarc':'0'})
label = df['Label'].tolist()
qt = df['Quote Text'].tolist()
rt = df['Response Text'].tolist()

labels = []
q = []
r = []
for sent1,sent2,l in zip(rt,qt,label):
    r.append(dl.clean(sent1))
    q.append(dl.clean(sent2))
    labels.append(dl.clean(l))

f = open('glove.6B.50d.txt', encoding="utf8")
model = {}
for line in f:
    splitline = line.split()
    word = splitline[0]
    embedding = np.array([float(val) for val in splitline[1:]])
    model[word] = embedding
    
wordvec_model = model

data_inp_l, data_inp_r, embedding_matrix = dl.process_data(sent_l = q, sent_r = r, wordVec_model = wordvec_model, dimx = 100, dimy = 100)
model = model_cnn(dimx = 100, embedding_matrix = embedding_matrix)



#data_inp_l, data_inp_r, embedding_matrix = dl.process_data(sent_l = q, sent_r = r, wordVec_model = wordvec_model, dimx = 10, dimy = 10)
#
#model = model_cnn2(dimx = 10, dimy = 10, embedding_matrix = embedding_matrix)
#model.fit([data_inp_l, data_inp_r], labels)
